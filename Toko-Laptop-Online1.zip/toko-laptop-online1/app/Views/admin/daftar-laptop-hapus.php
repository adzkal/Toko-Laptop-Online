<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Laptop</title>
    <link rel="stylesheet" href="/path/to/your/css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Konfirmasi Hapus Laptop</h1>
        
        <?php if (isset($laptop)): ?>
            <p>Apakah Anda yakin ingin menghapus Laptop dengan data berikut?</p>
            <ul>
                <li><strong>Merek:</strong> <?= htmlspecialchars($laptop['merek']); ?></li>
                <li><strong>Spesifikasi:</strong> <?= htmlspecialchars($laptop['spesifikasi']); ?></li>
                <li><strong>Tahun Rilis:</strong> <?= htmlspecialchars($laptop['tahun_rilis']); ?></li>
                <li><strong>Gambar:</strong> <?= htmlspecialchars($laptop['gambar']); ?></li>
                <li><strong>Harga:</strong> Rp <?= number_format($laptop['harga'], 2, ',', '.'); ?></li>
            </ul>
            
            <form action="/admin/daftar-laptop/hapus<?= $laptop['id']; ?>" method="post">
                <?= csrf_field(); ?>
                
                <button type="submit" class="btn btn-danger">Hapus</button>
                <a href="/admin/daftar-laptop" class="btn btn-secondary">Batal</a>
            </form>
        <?php else: ?>
            <a href="/admin/daftar-laptop" class="btn btn-secondary">Kembali ke Daftar Laptop</a>
        <?php endif; ?>
    </div>
</body>
</html>