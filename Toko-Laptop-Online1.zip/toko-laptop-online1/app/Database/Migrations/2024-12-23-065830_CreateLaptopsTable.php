<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateLaptopsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'auto_increment' => true,
            ],
            'merek' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'model' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'spesifikasi' => [
                'type' => 'TEXT',
            ],
            'tahun_rilis' => [
                'type' => 'INT',
                'constraint' => 4,
            ],
            'gambar' => [
                'type' => 'VARCHAR',
                'constraint' => 250,
            ],
            'harga' => [
                'type' => 'INT',
                'constraint' => 16,
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->createTable('laptops');
    }

    public function down()
    {
        $this->forge->dropTable('laptops');
    }
}
