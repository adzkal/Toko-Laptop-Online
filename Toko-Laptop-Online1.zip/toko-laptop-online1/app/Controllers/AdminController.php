<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    public function index()
    {
        return view('admin/dashboard');
    }

    public function daftarLaptop(){
        $laptopModel = model('laptopModel');

        $data['laptops'] = $laptopModel->findAll();

        return view('admin/daftar-laptop', $data);
    }

    public function daftarLaptopTambah(){
        return view('admin/daftar-laptop-tambah');
    }

    public function createLaptop(){
        $data = $this->request->getPost();
       
        $laptopModel = model('laptopModel');

        if($laptopModel->insert($data, false)){;

        return redirect()->to('admin/daftar-laptop')->with('berhasil', 'Data berhasil disimpan!');
        }else{
            return redirect()->to('admin/daftar-laptop')->with('gagal', 'Data gagal disimpan!');
        }
    }

    public function daftarLaptopEdit(){
        return view('admin/daftar-laptop-edit');
    }

    public function daftarLaptopHapus(){
        return view('admin/daftar-laptop-hapus');
    }

    public function transaksi(){
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus(){
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus(){
        return view('admin/transaksi-hapus');
    }

    public function pelanggan(){
        return view('admin/pelanggan');
    }

    public function pelangganHapus(){
        return view('admin/pelanggan-hapus');
    }
}