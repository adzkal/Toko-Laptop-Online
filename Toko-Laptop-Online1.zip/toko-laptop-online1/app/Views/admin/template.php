<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Toko Laptop Online</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?= base_url()?>css/style.css">
    <style>
      body {
        background-color: #f8f9fa;
      }
      .sidebar {
        background-color: #343a40;
        color: white;
        min-height: 100vh;
        padding: 20px;
      }
      .sidebar a {
        color: #ffffff;
        text-decoration: none;
      }
      .sidebar a:hover {
        text-decoration: underline;
      }
      .sidebar ul {
        list-style-type: none;
        padding: 0;
      }
      .sidebar li {
        margin-bottom: 15px;
      }
      footer {
        background-color: #343a40;
        color: white;
      }
      .navbar {
        background-color: #343a40;
        color: white;
      }
    </style>
  </head>
  <body>

    <nav class="navbar navbar-expand-lg navbar-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">Admin Panel</a>
        <div class="d-flex">
          <a href="<?= base_url('logout') ?>" class="btn btn-danger">Logout</a>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-3 sidebar">
          <h4>Menu</h4>
          <ul>
            <li>
              <a href="<?= base_url('admin/dashboard') ?>">Dashboard</a>
            </li>
            <li>
              <a href="<?= base_url('admin/daftar-laptop') ?>">Daftar Laptop</a>
            </li>
            <li>
              <a href="<?= base_url('admin/transaksi') ?>">Transaksi</a>
            </li>
            <li>
              <a href="<?= base_url('admin/pelanggan') ?>">Pelanggan</a>
            </li>
          </ul>
        </div>
        <div class="col-9">
          <div class="p-4">
            <?= $this->renderSection('main'); ?>
          </div>
        </div>
      </div>
    </div>

    <footer class="py-4 mt-5 text-center">
      <div class="container">
        &copy; Copyright 2024. Toko Laptop Online Muh.Adzkal Akhdan. All Rights reserved.
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
