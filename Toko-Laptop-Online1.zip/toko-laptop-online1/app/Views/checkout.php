<?= $this->extend('template') ?>

<?= $this->section('main') ?>
<div class="container">
    <h2>JNE Express</h2>
    <hr />
    <h5>Ongkos Kirim</h5> 
    <h5>Rp30,000</h5>

    <h2 class="mt-3">Alamat pengiriman</h2>
    <hr />
    <h5>Jl.Mawar Merah - Jakarta KM 16, Jakarta Selatan.</h5>

    <h2 class="mt-3">Metode Bayar</h2>
    <hr />
    <h5>Transfer Bank</h5>
    <h5>BRI UDIN DINAMO</h5>
    <h5>Rek. 665544332211</h5>

    <div class="mt-5">
        <form action="<?= base_url('submit')?>" method="POST">
            <button type="submit" class="btn btn-success">Submit Order</button>
        </form>
    </div>
</div>
<?= $this->endSection() ?>