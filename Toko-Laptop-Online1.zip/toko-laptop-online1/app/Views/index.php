<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko Laptop Online</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <style>
      .hero {
        background: linear-gradient(
          to right,
          #0d6efd,
          #6610f2
        );
        color: white;
        padding: 50px 20px;
        border-radius: 10px;
      }
      .card:hover {
        transform: translateY(-10px);
        transition: all 0.3s ease;
      }
      footer {
        background-color: #343a40;
        color: white;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <!-- Header -->
      <header class="py-3 mb-5 border-bottom">
        <div class="d-flex justify-content-between align-items-center">
          <h1 class="text-primary">Toko Laptop Online</h1>
          <a href="<?= base_url() ?>chart" class="btn btn-secondary">
            Keranjang Belanja <span class="badge bg-warning">3</span>
          </a>
        </div>
      </header>

      <!-- Hero Section -->
      <div class="hero mb-5 text-center">
        <h2 class="display-4">Selamat Datang di Toko Laptop Online</h2>
        <p class="lead">Kami menyediakan laptop dari berbagai merek ternama</p>
      </div>

      <!-- Search Section -->
      <div class="row mb-5">
        <div class="col-md-6 mx-auto">
          <h3 class="text-center mb-4">Cari Laptop Impian Anda</h3>
          <form action="" class="bg-light p-4 rounded shadow-sm">
            <div class="mb-3">
              <input
                type="text"
                class="form-control"
                placeholder="Merek Laptop"
              />
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="Harga" />
            </div>
            <button class="btn btn-primary w-100">Cari</button>
          </form>
        </div>
      </div>

      <!-- Best Seller Section -->
      <section>
        <h2 class="mb-4 text-center">Laptop Best Seller</h2>
        <div class="row g-4">
          <div class="col-md-3">
            <div class="card shadow-sm">
              <img src="images/laptop1.jpg" class="card-img-top"  />
              <div class="card-body text-center">
                <h5 class="card-title">ACER</h5>
                <p class="card-text">Rp 8,000,000,-</p>
                <a href="#" class="btn btn-primary w-100">Add to Cart</a>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow-sm">
              <img src="images/laptop2.jpg" class="card-img-top"  />
              <div class="card-body text-center">
                <h5 class="card-title">ASUS</h5>
                <p class="card-text">Rp 10,000,000,-</p>
                <a href="#" class="btn btn-primary w-100">Add to Cart</a>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow-sm">
              <img src="images/laptop3.jpg" class="card-img-top"  />
              <div class="card-body text-center">
                <h5 class="card-title">Hp</h5>
                <p class="card-text">Rp 6,000,000,-</p>
                <a href="#" class="btn btn-primary w-100">Add to Cart</a>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow-sm">
              <img src="images/laptop4.jpg" class="card-img-top"  />
              <div class="card-body text-center">
                <h5 class="card-title">Lenovo</h5>
                <p class="card-text">Rp 5,000,000,-</p>
                <a href="#" class="btn btn-primary w-100">Add to Cart</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

    <!-- Footer -->
    <footer class="py-4 mt-5 text-center">
      <div>&copy; 2024. Toko Laptop Online Muh.Adzkal Akhdan. All Rights Reserved.</div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
