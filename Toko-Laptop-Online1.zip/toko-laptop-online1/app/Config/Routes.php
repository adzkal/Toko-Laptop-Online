<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/chart', 'Home::chart');
$routes->get('/checkout', 'Home::checkout');

$routes->post('/submit', 'Home::submit');

$routes->get('images/(:segmen)', 'Home::image/$1');

$routes->group('admin', ['filter' => ['group:admin']], function ($routes) {

    $routes->get('', 'AdminController::index');
    $routes->get('dashboard', 'AdminController::index');
    
    $routes->get('daftar-laptop', 'AdminController::daftarLaptop');
    $routes->get('daftar-laptop/tambah', 'AdminController::daftarLaptopTambah');
    $routes->post('daftar-laptop/create', 'AdminController::createLaptop');
    $routes->get('daftar-laptop/edit', 'AdminController::daftarLaptopEdit');
    $routes->post('daftar-laptop/update', 'AdminController::updateLaptop');
    $routes->get('daftar-laptop/hapus/(:num)', 'AdminController::daftarLaptopHapus/$1');
    $routes->get('daftar-laptop/hapus/(:num)', 'AdminController::daftarLaptopHapus/$1');
    $routes->post('daftar-laptop/hapus/(:num)', 'AdminController::daftarLaptopHapus/$1');
    
    $routes->get('transaksi', 'AdminController::transaksi');
    $routes->get('transaksi/ubah-status', 'AdminController::transaksiUbahStatus');
    $routes->get('transaksi/hapus', 'AdminController::transaksiHapus');
    
    $routes->get('pelanggan', 'AdminController::pelanggan');
    $routes->get('pelanggan/hapus', 'AdminController::pelangganHapus');
});

service('auth')->routes($routes);
