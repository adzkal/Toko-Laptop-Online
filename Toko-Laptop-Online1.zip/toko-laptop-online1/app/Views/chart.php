<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Chart - Toko Laptop Online</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <style>
      .cart-item {
        background: #f9f9f9;
        border-radius: 10px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }
      .cart-item:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      }
      footer {
        background-color: #343a40;
        color: white;
        text-align: center;
      }
      .btn-primary,
      .btn-danger {
        transition: all 0.3s ease;
      }
      .btn-primary:hover {
        background-color: #0056b3;
        border-color: #004085;
      }
      .btn-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
      }
    </style>
  </head>
  <body>
    <div class="container my-5">
      <!-- Header -->
      <div class="row mb-5">
        <div class="col-12 text-end">
          <a href="chart.html" class="btn btn-secondary"
            >Keranjang belanja <span class="badge text-bg-warning">3</span></a
          >
        </div>
      </div>

      <!-- Title -->
      <h2 class="mb-5 text-center fw-bold text-primary">Keranjang Belanja</h2>

      <!-- Cart Items -->
      <div class="row mb-5 g-4">
        <div class="col-12 cart-item p-4">
          <div class="row align-items-center">
            <div class="col-md-4 text-center">
              <img
                src="images/laptop1.jpg"
                alt="Laptop 1"
                class="img-fluid rounded"
                style="max-width: 200px"
              />
            </div>
            <div class="col-md-3 text-center">
              <h5 class="mb-0">ACER</h5>
            </div>
            <div class="col-md-2 text-center">
              <span class="badge bg-primary fs-5">x1</span>
            </div>
            <div class="col-md-3 text-center">
              <button class="btn btn-danger w-100" onclick="hapusItem('laptop1')">
                Hapus
              </button>
            </div>
          </div>
        </div>

        <!-- Additional Items -->
        <div class="col-12 cart-item p-4">
          <div class="row align-items-center">
            <div class="col-md-4 text-center">
              <img
                src="images/laptop2.jpg"
                alt="Laptop 2"
                class="img-fluid rounded"
                style="max-width: 200px"
              />
            </div>
            <div class="col-md-3 text-center">
              <h5 class="mb-0">ASUS</h5>
            </div>
            <div class="col-md-2 text-center">
              <span class="badge bg-primary fs-5">x1</span>
            </div>
            <div class="col-md-3 text-center">
              <button class="btn btn-danger w-100" onclick="hapusItem('laptop2')">
                Hapus
              </button>
            </div>
          </div>
        </div>

        <div class="col-12 cart-item p-4">
          <div class="row align-items-center">
            <div class="col-md-4 text-center">
              <img
                src="images/laptop3.jpg"
                alt="Laptop 3"
                class="img-fluid rounded"
                style="max-width: 200px"
              />
            </div>
            <div class="col-md-3 text-center">
              <h5 class="mb-0">HP</h5>
            </div>
            <div class="col-md-2 text-center">
              <span class="badge bg-primary fs-5">x1</span>
            </div>
            <div class="col-md-3 text-center">
              <button class="btn btn-danger w-100" onclick="hapusItem('laptop3')">
                Hapus
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Total and Actions -->
      <div class="row justify-content-end mb-5">
        <div class="col-md-4 text-center">
          <h3>Total: <span class="text-success">Rp24,000,000</span></h3>
        </div>
      </div>
      <div class="row mb-5 text-center">
        <div class="col-md-6">
          <a href="<?= base_url() ?>" class="btn btn-secondary w-100">Kembali Berbelanja</a>
        </div>
        <div class="col-md-6">
          <a href="<?= base_url('checkout') ?>" class="btn btn-primary w-100">
            Checkout
          </a>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="py-3">
      <div class="container">
        &copy; 2024 Toko Laptop Online Muh.Adzkal Akhdan. All Rights Reserved.
      </div>
    </footer>

    <script>
      function hapusItem(itemId) {
        if (confirm("Apakah Anda yakin ingin menghapus item ini dari keranjang?")) {
          console.log(`Item dengan ID ${itemId} telah dihapus.`);
          location.reload();
        }
      }
    </script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
